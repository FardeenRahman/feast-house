<?php

$conn = mysqli_connect("localhost", "root", "", "feast_house");
if($conn){
    echo"connect";
}

?>